﻿namespace MovieStoreMvc.Models.DTO
{
    public class AccountManagementModel
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Username { get; set; }
        public bool IsAdmin { get; set; }
    }
}
